CROCKCELL FINAL V2
==================

Replace ALL 11 old HTML files with these 11 files together.
There is NO separate CSS, JS, or config file.

Files:
1. index.html
2. signup.html
3. forgot-password.html
4. home.html
5. search.html
6. profile.html
7. messages.html
8. create.html
9. reels.html
10. activity.html
11. edit-profile.html

Important unified session keys:
- crockcell_idToken
- crockcell_refreshToken
- crockcell_uid
- crockcell_profile

This package keeps the current CROCKCELL UI/features and fixes the old/new
session-key mismatch that affected Create/Reels/Activity/Edit Profile.
Search -> Profile uses sessionStorage + URL data.
Profile -> Message uses sessionStorage + URL data.

Do not mix old versions with these files. Upload/replace all 11 together.
